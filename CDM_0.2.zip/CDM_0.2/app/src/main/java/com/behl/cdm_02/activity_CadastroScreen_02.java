package com.behl.cdm_02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_CadastroScreen_02 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro_screen_02);
    }
}
