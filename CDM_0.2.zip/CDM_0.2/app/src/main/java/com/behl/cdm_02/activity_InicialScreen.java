package com.behl.cdm_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.parse.ParseUser;

public class activity_InicialScreen extends AppCompatActivity {

    private ViewPager viewPager;
    private LinearLayout linearLayout;
    private SliderAdapter sliderAdapter;
    private TextView[] boats;
    private int currentPage;

    SharedPreferences sPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.inicial_screen);

        Button btnNext = findViewById(R.id.btnAvancar);
        final Button btnBack = findViewById(R.id.btnVoltar);

        viewPager = findViewById(R.id.slideViewPager);
        linearLayout = findViewById(R.id.linear);

        sliderAdapter = new SliderAdapter(this);
        viewPager.setAdapter(sliderAdapter);

        addDots(0);
        viewPager.addOnPageChangeListener(viewListener);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentPage == 2){
                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);

                    Intent intentTo_loginScreen = new Intent(getApplicationContext(), activity_LoginScreen.class);
                    startActivity(intentTo_loginScreen);
                }
                viewPager.setCurrentItem(currentPage+1);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(currentPage-1);
            }
        });
    }

    @Override
    public void onResume () {
        super.onResume();

        sPreferences = getSharedPreferences("com.behl.cdm_02", MODE_PRIVATE);

        if (ParseUser.getCurrentUser() != null) {
            Intent intent = new Intent(getApplicationContext(), activity_PrincipalScreen.class);
            startActivity(intent);
            Snackbar.make(linearLayout,"Bem-Vindo de volta!", Snackbar.LENGTH_SHORT).show();

        } else {
            if (sPreferences.getString("inicial_if", null) == "yes"){
                Intent intent = new Intent(getApplicationContext(), activity_LoginScreen.class);
                startActivity(intent);
                Snackbar.make(linearLayout,"Bem-Vindo de volta!", Snackbar.LENGTH_SHORT).show();

            }
            Snackbar.make(linearLayout,"Seja bem-vindo à Família!", Snackbar.LENGTH_SHORT).show();
        }
    }

    public void addDots(int position){
        boats = new TextView[3];
        linearLayout.removeAllViews();
        for(int i = 0; i < boats.length;i++) {

            boats[i] = new TextView(this);
            boats[i].setText(Html.fromHtml("&#8226;"));
            boats[i].setTextSize(35);
            boats[i].setTextColor(getResources().getColor(R.color.colorPrimaryDark));

            linearLayout.addView(boats[i]);
        }

        if(boats.length > 0){
            boats[position].setTextColor(getResources().getColor(R.color.colorAccent));

        }

    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener(){

        @Override
        public void onPageScrolled(int i, float v, int i1) {

        }

        @Override
        public void onPageSelected(int i) {
            Log.i("PAGESELECTED", String.valueOf(i));
            currentPage = i;
            Button btnBack = findViewById(R.id.btnVoltar);
            Button btnNext = findViewById(R.id.btnAvancar);

            if(i==0)
            {
                btnNext.setEnabled(true);
                btnBack.setEnabled(false);
                btnBack.setVisibility(View.GONE);

                btnNext.setText("Próxima");
            }
            else if(i==1){
                btnNext.setEnabled(true);
                btnBack.setEnabled(true);
                btnBack.setVisibility(View.VISIBLE);
                btnNext.setText("Próxima");
            }
            else{

                btnNext.setEnabled(true);
                btnBack.setEnabled(true);
                btnBack.setVisibility(View.VISIBLE);
                btnNext.setText("Avançar");

            }

            addDots(i);
        }

        @Override
        public void onPageScrollStateChanged(int i) {

        }
    };
}
